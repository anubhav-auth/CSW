import React from 'react';
import { motion } from 'framer-motion';

const ProfileImage = () => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.5 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="relative w-48 h-48 mx-auto mb-8"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full animate-pulse" />
      <motion.div
        whileHover={{ scale: 1.05 }}
        className="relative w-full h-full rounded-full overflow-hidden border-4 border-gray-800"
      >
        <img
          src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200&h=200"
          alt="Anubhav Jaiswal"
          className="w-full h-full object-cover"
        />
      </motion.div>
    </motion.div>
  );
};

export default ProfileImage;