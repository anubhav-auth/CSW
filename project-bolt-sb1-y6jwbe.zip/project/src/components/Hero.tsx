import React from 'react';
import { motion } from 'framer-motion';
import { Code2, Laptop, Server } from 'lucide-react';
import ProfileImage from './ProfileImage';

const Hero = () => {
  return (
    <section className="min-h-screen pt-24 pb-12 px-6 bg-gradient-to-b from-gray-900 to-gray-800">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <ProfileImage />
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mb-8"
          >
            <h1 className="text-7xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-purple-400 via-pink-500 to-purple-400 bg-clip-text text-transparent animate-gradient">
              Anubhav Jaiswal
            </h1>
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-200">
              Android & Full Stack Developer
            </h2>
          </motion.div>
          <p className="text-gray-300 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
            Passionate about creating intuitive, performance-optimized applications with expertise in Android, 
            full-stack, and cross-platform development.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 mt-16">
          <SkillCard 
            icon={<Laptop className="w-8 h-8" />}
            title="Android Development"
            skills={['Jetpack Compose', 'Compose Multiplatform', 'MVVM', 'Kotlin']}
          />
          <SkillCard 
            icon={<Server className="w-8 h-8" />}
            title="Backend Development"
            skills={['Spring Boot', 'GraphQL', 'Ktor', 'REST APIs']}
          />
          <SkillCard 
            icon={<Code2 className="w-8 h-8" />}
            title="Technologies"
            skills={['Docker', 'Git', 'MongoDB', 'Firebase']}
          />
        </div>
      </div>
    </section>
  );
};

const SkillCard = ({ icon, title, skills }: { icon: React.ReactNode; title: string; skills: string[] }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6, delay: 0.2 }}
    whileHover={{ scale: 1.02 }}
    className="bg-gray-800 p-8 rounded-xl border border-gray-700 shadow-xl backdrop-blur-sm"
  >
    <div className="text-purple-400 mb-6">{icon}</div>
    <h3 className="text-2xl font-semibold mb-6 text-white">{title}</h3>
    <ul className="space-y-3">
      {skills.map((skill) => (
        <motion.li 
          key={skill}
          whileHover={{ x: 5 }}
          className="flex items-center space-x-2"
        >
          <span className="w-2 h-2 bg-purple-400 rounded-full" />
          <span className="text-gray-300 hover:text-purple-400 transition-colors cursor-default">
            {skill}
          </span>
        </motion.li>
      ))}
    </ul>
  </motion.div>
);

export default Hero;