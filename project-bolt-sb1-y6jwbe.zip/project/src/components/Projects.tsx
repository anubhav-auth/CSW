import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ExternalLink, Github } from 'lucide-react';

const projects = [
  {
    title: 'BookPedia',
    description: 'Cross-Platform Book Companion built with Compose Multiplatform, reducing development time by 40%.',
    tech: ['Compose Multiplatform', 'Ktor', 'Koin', 'Room'],
    image: 'https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&q=80&w=800&h=400'
  },
  {
    title: 'Bento',
    description: 'Full-Stack Restaurant Ordering App with real-time order tracking and seamless user experience.',
    tech: ['Kotlin', 'Spring Boot', 'MongoDB', 'Docker'],
    image: 'https://images.unsplash.com/photo-1565299543923-37dd37887442?auto=format&fit=crop&q=80&w=800&h=400'
  },
  {
    title: 'CoinLog',
    description: 'Personal Finance Manager with secure authentication and robust budget-setting system.',
    tech: ['Kotlin', 'Jetpack Compose', 'Room', 'Firebase'],
    image: 'https://images.unsplash.com/photo-1518186285589-2f7649de83e0?auto=format&fit=crop&q=80&w=800&h=400'
  }
];

const Projects = () => {
  return (
    <section className="py-20 px-6 bg-gray-900">
      <div className="container mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl font-bold text-center mb-12 bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent"
        >
          Featured Projects
        </motion.h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={project.title} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

const ProjectCard = ({ project, index }: { project: any; index: number }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      className="bg-gray-800/50 rounded-xl overflow-hidden border border-gray-700"
    >
      <img 
        src={project.image} 
        alt={project.title}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2 text-white">{project.title}</h3>
        <p className="text-gray-400 mb-4">{project.description}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {project.tech.map((tech: string) => (
            <span key={tech} className="px-3 py-1 text-sm bg-purple-500/20 text-purple-400 rounded-full">
              {tech}
            </span>
          ))}
        </div>
        <div className="flex space-x-4">
          <motion.a
            href="#"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="text-purple-400 hover:text-purple-300"
          >
            <Github className="w-6 h-6" />
          </motion.a>
          <motion.a
            href="#"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="text-purple-400 hover:text-purple-300"
          >
            <ExternalLink className="w-6 h-6" />
          </motion.a>
        </div>
      </div>
    </motion.div>
  );
};

export default Projects;